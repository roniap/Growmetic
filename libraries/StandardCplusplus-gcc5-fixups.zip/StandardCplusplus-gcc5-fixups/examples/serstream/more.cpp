#include <serstream>
#include <Arduino.h>

void more(void)
{
  Serial.print("more");

  std::cout << 1.0f;
}
